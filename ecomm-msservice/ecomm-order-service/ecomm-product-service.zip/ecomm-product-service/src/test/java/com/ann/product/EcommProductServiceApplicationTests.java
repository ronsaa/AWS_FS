package com.ann.product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommProductServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
